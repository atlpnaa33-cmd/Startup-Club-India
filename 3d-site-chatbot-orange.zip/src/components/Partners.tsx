import { motion } from 'framer-motion';
import { useInView } from './useInView';

const partners = [
  { name: 'NASSCOM', emoji: '🏛️' },
  { name: 'Startup India', emoji: '🇮🇳' },
  { name: 'Google for Startups', emoji: '🔍' },
  { name: 'AWS Activate', emoji: '☁️' },
  { name: 'Microsoft BizSpark', emoji: '💻' },
  { name: 'DPIIT', emoji: '🏢' },
  { name: 'TiE Global', emoji: '🌍' },
  { name: 'YCombinator', emoji: '🚀' },
];

export function Partners() {
  const { ref, inView } = useInView();

  return (
    <section className="py-16 bg-gray-50 relative overflow-hidden" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.p
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center text-sm font-semibold text-gray-400 uppercase tracking-widest mb-10"
        >
          Trusted & Supported By
        </motion.p>

        <div className="flex flex-wrap justify-center gap-6">
          {partners.map((p, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.08 * i, duration: 0.5 }}
              className="group flex items-center gap-3 px-6 py-4 bg-white rounded-2xl border border-gray-100 hover:border-orange-200 hover:shadow-md hover:shadow-orange-50 transition-all duration-300 cursor-default"
            >
              <span className="text-2xl group-hover:scale-110 transition-transform">{p.emoji}</span>
              <span className="text-sm font-semibold text-gray-600 group-hover:text-orange-600 transition-colors">{p.name}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
